import QtGraphicalEffects 1.0
import QtMultimedia 5.4
import QtQuick 2.3
import QtQuick.Controls 2.12
import QtQuick.Controls.Material 2.2
import QtQuick.Dialogs 1.3
import QtQuick.Layouts 1.10
import Ros2 1.0
import "component"

Item {
    id: page

    property var change_control_mode: Ros2.createPublisher("/nb/change_control_mode", "std_msgs/msg/Int8", 10)
    property var playback_pub: Ros2.createPublisher("/nb/play_back_overlay", "std_msgs/msg/String", 10)
    property var change_playback_speed: Ros2.createPublisher("/nb/playback_speed", "std_msgs/msg/Float32", 10)

    width: 300
    height: 300
    Component.onCompleted: {
        // Initialize ROS with the given name. The command line args are passed by the plugin
        // Optionally, you can call init with a string list ["arg1", "arg2"] after the name to use those
        // args instead of the ones supplied by the command line.
        Ros2.init("overlay_gitex_demo_rviz2");
    }

    Connections {
        function onShutdown() {
            Qt.quit();
        }

        target: Ros2
    }

    Subscription {
        id: status_command_multiple

        topic: "/nb/status_command_multiple"
        onNewMessage: desired_control_mode.external_refresh = message.data
    }

    Subscription {
        id: status_play_back

        topic: "/nb/play_back_state"
        onNewMessage: {
            var datas = message.data.split(";");
            playback_loop.loop = datas[2].split("=")[1] === 'True';
            speedSlider.value = datas[1].split("=")[1];
            playback_param_Window.selectedFolder = datas[0].split("=")[1].slice(0, -1);
            if (playback_param_Window.selectedFolder === '') {
                playback_start.visible = false;
                playback_stop.visible = false;
                playback_pause.visible = false;
                playback_loop.visible = false;
            } else {
                playback_start.visible = datas[3].split("=")[1] === 'pause';
                playback_pause.visible = datas[3].split("=")[1] === 'play';
                playback_loop.visible = true;
                playback_stop.visible = true;
            }
        }
    }

    Subscription {
        id: status_driver_circular_carrier

        topic: "/circular_carrier/status_driver"
        onNewMessage: {
            var devs = message.devices.toArray();
            battery_level._rawPourcentage = 100 * (devs[0].voltage_logic - (3.2 * 6)) / ((4.2 - 3.2) * 6);
        }
    }

    Subscription {
        id: status_interactive_marker

        topic: "/interactive_tf_controller_EE/status"
        onNewMessage: {
            slider_interactive_marker_cartesian.value = message.data;
        }
    }

    Frame {
        id: principal_frame

        width: 300
        height: 300
        padding: 20

        Column {
            anchors.fill: parent
            spacing: 16

            ComboBox {
                id: desired_control_mode

                property int external_refresh: -1

                anchors.horizontalCenter: parent.horizontalCenter
                width: 230
                height: 50
                textRole: "text"
                onExternal_refreshChanged: {
                    for (var i = 0; i < desired_control_mode.model.count; i++) {
                        if (desired_control_mode.model.get(i).cmd === external_refresh)
                            currentIndex = i;

                    }
                }
                onCurrentIndexChanged: {
                    if (desired_control_mode.model.get(currentIndex).cmd != external_refresh)
                        page.change_control_mode.publish({
                        "data": desired_control_mode.model.get(desired_control_mode.currentIndex).cmd
                    });

                    //playback mode
                    if (desired_control_mode.model.get(desired_control_mode.currentIndex).text == 'Playback')
                        playback_param_Window.visible = true;
                    else
                        playback_param_Window.visible = false;
                }

                background: Rectangle {
                    radius: 4
                    border.color: "#000000"
                    border.width: 2
                }

                model: ListModel {
                    ListElement {
                        text: "Pause"
                        icon: "qrc:/pause.png"
                        cmd: 0
                    }

                    ListElement {
                        text: "Cartésien"
                        icon: "qrc:/cartesian.png"
                        cmd: 1
                    }

                    ListElement {
                        text: "Modulaire"
                        icon: "qrc:/modular.png"
                        cmd: 2
                    }

                    ListElement {
                        text: "Suivi de chemin"
                        icon: "qrc:/path_follow.png"
                        cmd: 3
                    }

                    ListElement {
                        text: "Planification"
                        icon: "qrc:/cartesian.png"
                        cmd: 4
                    }

                    ListElement {
                        text: "Scout"
                        icon: "qrc:/scout.png"
                        cmd: 5
                    }

                    ListElement {
                        text: "Playback"
                        icon: "qrc:/playback.png"
                        cmd: 6
                    }

                }

                delegate: ItemDelegate {
                    width: parent.width
                    highlighted: ListView.isCurrentItem

                    contentItem: Row {
                        spacing: 8

                        Image {
                            source: model.icon
                            width: 30
                            height: 30
                            fillMode: Image.PreserveAspectFit
                            verticalAlignment: Text.AlignVCenter
                            anchors.verticalCenter: parent.verticalCenter
                        }

                        Text {
                            text: model.text
                            font.pixelSize: 20
                            font.bold: true
                            color: "#000000"
                            verticalAlignment: Text.AlignVCenter
                            anchors.verticalCenter: parent.verticalCenter
                        }

                    }

                }

                contentItem: Row {
                    spacing: 8
                    anchors.fill: parent
                    anchors.margins: 4

                    Image {
                        id: currentIcon

                        width: 30
                        height: 30
                        fillMode: Image.PreserveAspectFit
                        verticalAlignment: Text.AlignVCenter
                        anchors.top: parent.top
                        anchors.leftMargin: 10
                        anchors.verticalCenter: parent.verticalCenter
                        source: desired_control_mode.currentIndex >= 0 ? desired_control_mode.model.get(desired_control_mode.currentIndex).icon : ""
                    }

                    Text {
                        id: currentText

                        font.pixelSize: 20
                        font.bold: true
                        color: "#000000"
                        text: desired_control_mode.currentText
                        elide: Text.ElideRight
                        verticalAlignment: Text.AlignVCenter
                        horizontalAlignment: Text.AlignHCenter
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.top: parent.top
                        anchors.leftMargin: 45
                    }

                }

            }

            Rectangle {
                id: button

                property bool pressed: true

                signal emergencyStop()

                width: 180
                height: 180
                radius: width / 2
                color: "#d32f2f" // Rouge vif
                border.color: "#eeeeee"
                border.width: 6
                antialiasing: true
                anchors.horizontalCenter: parent.horizontalCenter
                // Ombre portée sous le bouton
                layer.enabled: true

                // Effet de relief (biseautage simulé)
                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: "transparent"
                    border.color: "#ff7979"
                    border.width: 3
                    layer.enabled: true

                    layer.effect: InnerShadow {
                        radius: 10
                        samples: 32
                        color: "#55000000"
                        horizontalOffset: 0
                        verticalOffset: 3
                        spread: 0.5
                    }

                }

                // Le bouton rouge "physique" avec effet d’enfoncement
                Rectangle {
                    id: topButton

                    anchors.centerIn: parent
                    width: parent.width * 0.85
                    height: parent.height * 0.85
                    radius: width / 2
                    color: button.pressed ? "#a12727" : "#e53935"
                    border.color: button.pressed ? "#7a1f1f" : "#ff9999"
                    border.width: 4
                    antialiasing: true
                    scale: button.pressed ? 0.95 : 1

                    Behavior on scale {
                        NumberAnimation {
                            duration: 120
                            easing.type: Easing.OutQuad
                        }

                    }

                }

                Text {
                    anchors.centerIn: parent
                    text: "STOP"
                    font.pixelSize: 36
                    font.bold: true
                    color: "yellow"
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    z: 1
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.verticalCenter: parent.verticalCenter
                    opacity: button.pressed ? 0.7 : 1
                }

                MouseArea {
                    anchors.fill: parent
                    onPressed: button.pressed = true
                    onReleased: {
                        if (button.pressed) {
                            button.pressed = false;
                            desired_control_mode.currentIndex = 0;
                            button.emergencyStop();
                        }
                    }
                    cursorShape: Qt.PointingHandCursor
                }

                layer.effect: DropShadow {
                    anchors.fill: button
                    radius: 20
                    samples: 32
                    horizontalOffset: 0
                    verticalOffset: 8
                    color: "#66000000"
                }

            }

        }

        background: Rectangle {
            color: "transparent"
            border.width: 0
        }

    }

    Rectangle {
        id: playback_param_Window

        property bool canvasesVisible: false
        property string selectedFolder: ""
        property int itemHeight: 32
        property int activeRosbagIndex: -1

        width: 350
        x: 0
        y: principal_frame.height
        color: "#f0f0f0"
        radius: 10
        border.color: "#666"
        border.width: 2
        visible: desired_control_mode.currentIndex >= 0 && desired_control_mode.model.get(desired_control_mode.currentIndex).text === "Playback"
        height: implicitHeight
        implicitHeight: content.implicitHeight

        Timer {
            id: playbackTimer

            interval: 100 // update every 100 ms
            repeat: true
            running: false
            onTriggered: {
                if (playback_param_Window.activeRosbagIndex >= 0) {
                    var idx = playback_param_Window.activeRosbagIndex;
                    var p = Math.min(1, rosbagModel.get(idx).progress + 0.01);
                    rosbagModel.setProperty(idx, "progress", p);
                }
            }
        }

        Column {
            id: content

            anchors.fill: parent
            spacing: 16

            Rectangle {
                id: playback_title

                width: parent.width
                height: 30
                color: "#444"
                radius: 5

                Text {
                    text: "Playback"
                    anchors.centerIn: parent
                    color: "white"
                }

                MouseArea {
                    anchors.fill: parent
                    drag.target: playback_param_Window
                    drag.axis: Drag.XAndYAxis
                    cursorShape: Qt.OpenHandCursor
                    onPressed: cursorShape = Qt.ClosedHandCursor
                    onReleased: cursorShape = Qt.OpenHandCursor
                    onClicked: {
                        playback_param_Window.canvasesVisible = !playback_param_Window.canvasesVisible;
                    }
                }

            }
            // List of rosbag files

            ListModel {
                id: rosbagModel
            }

            Column {
                width: parent.width
                spacing: 16
                visible: playback_param_Window.canvasesVisible

                Rectangle {
                    id: rect1

                    width: parent.width - 2 * (playback_param_Window.border.width)
                    color: "transparent"
                    implicitHeight: rect1Content.implicitHeight + rect1Content.anchors.margins + 16

                    Column {
                        id: rect1Content

                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.margins: 8
                        spacing: 8

                        Text {
                            text: "Rosbag"
                            anchors.horizontalCenter: parent.horizontalCenter
                            color: "black"
                            font.bold: true
                        }

                        MaterialToolButton {
                            iconName: "note_add"
                            anchors.horizontalCenter: parent.horizontalCenter
                            onClicked: folderDialog.open()
                        }

                        FileDialog {
                            id: folderDialog

                            title: "Sélectionnez un rosbag"
                            selectFolder: true
                            onAccepted: {
                                var folderPath = folderDialog.fileUrl.toString().split("/").pop();
                                console.log("Dossier choisi:", folderDialog.fileUrl);
                                rosbagModel.append({
                                    "path": folderPath,
                                    "progress": 0,
                                    "active": false
                                });
                                page.playback_pub.publish({
                                    "data": "path=" + folderPath
                                });
                            }
                            onRejected: console.log("Sélection annulée")
                        }

                        ListView {
                            id: listView

                            width: parent.width
                            height: Math.min(rosbagModel.count * playback_param_Window.itemHeight, 200)
                            model: rosbagModel
                            interactive: false

                            delegate: Item {
                                width: listView.width
                                height: playback_param_Window.itemHeight

                                Row {
                                    anchors.fill: parent
                                    spacing: 8

                                    Text {
                                        text: (index + 1) + ". "
                                        anchors.verticalCenter: parent.verticalCenter
                                    }

                                    Text {
                                        text: model.path
                                        anchors.verticalCenter: parent.verticalCenter
                                    }

                                    MaterialToolButtonGhost {
                                        // onClicked: todo make the "ghost" arm play the rosbag.

                                        iconName: "preview"
                                        anchors.verticalCenter: parent.verticalCenter
                                    }

                                    MaterialToolButtonGhost {
                                        iconName: "delete_forever"
                                        anchors.verticalCenter: parent.verticalCenter
                                        onClicked: rosbagModel.remove(index)
                                    }

                                }

                            }

                        }

                    }

                }
                // Playback parameters (speed, repetitions)

                Rectangle {
                    id: rect2

                    width: parent.width - 2 * (playback_param_Window.border.width)
                    color: "transparent"
                    implicitHeight: rect2Content.implicitHeight + rect2Content.anchors.margins + 16
                    visible: rosbagModel.count > 0

                    Column {
                        id: rect2Content

                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.margins: 8
                        spacing: 16

                        Text {
                            text: "Playback parameters"
                            anchors.horizontalCenter: parent.horizontalCenter
                            color: "black"
                            font.bold: true
                        }

                        Slider {
                            id: playback_speed

                            from: 0
                            to: 2
                            value: 1
                            stepSize: 0.1
                            orientation: Qt.Horizontal
                            width: parent.width
                            onValueChanged: page.change_playback_speed.publish({
                                "data": value
                            })
                        }

                        Text {
                            text: "Playback speed: " + playback_speed.value.toFixed(1) + "x"
                            anchors.horizontalCenter: parent.horizontalCenter
                            color: "black"
                        }

                        SpinBox {
                            id: playback_repetition

                            anchors.horizontalCenter: parent.horizontalCenter
                            from: 1
                            to: 10
                            stepSize: 1
                            value: 1
                            width: parent.width
                            height: 32
                            onValueChanged: page.playback_pub.publish({
                                "data": "repeat=" + value
                            })
                        }

                        Text {
                            text: "Playback repetitions: " + playback_repetition.value
                            color: "black"
                            anchors.horizontalCenter: parent.horizontalCenter
                        }

                        Row {
                            spacing: 8

                            MaterialToolButton {
                                iconName: "replay_5"
                                anchors.verticalCenter: parent.verticalCenter
                                onClicked: {
                                    if (playback_param_Window.activeRosbagIndex >= 0) {
                                        var idx = playback_param_Window.activeRosbagIndex;
                                        var newProgress = Math.min(1, rosbagModel.get(idx).progress - 0.1);
                                        rosbagModel.setProperty(idx, "progress", newProgress);
                                    }
                                }
                            }

                            MaterialToolButton {
                                iconName: "play_arrow"
                                anchors.verticalCenter: parent.verticalCenter
                                onClicked: {
                                    playback_param_Window.activeRosbagIndex = index;
                                    rosbagModel.setProperty(index, "active", true);
                                    // Optional: reset progress if starting from beginning
                                    rosbagModel.setProperty(index, "progress", 0);
                                    if (playback_param_Window.activeRosbagIndex >= 0) {
                                        var idx = playback_param_Window.activeRosbagIndex;
                                        // increment progress gradually using a timer
                                        playbackTimer.start();
                                    }
                                }
                            }

                            MaterialToolButton {
                                iconName: "pause"
                                anchors.verticalCenter: parent.verticalCenter
                                onClicked: {
                                    playbackTimer.stop();
                                }
                            }

                            MaterialToolButton {
                                iconName: "forward_5"
                                anchors.verticalCenter: parent.verticalCenter
                                onClicked: {
                                    if (playback_param_Window.activeRosbagIndex >= 0) {
                                        var idx = playback_param_Window.activeRosbagIndex;
                                        var newProgress = Math.min(1, rosbagModel.get(idx).progress + 0.1);
                                        rosbagModel.setProperty(idx, "progress", newProgress);
                                    }
                                }
                            }

                        }

                        Row {
                            id: progressRow

                            width: parent.width
                            spacing: 8

                            Repeater {
                                model: rosbagModel

                                delegate: ProgressBar {
                                    property bool active: model.active

                                    width: (progressRow.width - (rosbagModel.count - 1) * progressRow.spacing) / Math.max(1, rosbagModel.count)
                                    height: 16
                                    from: 0
                                    to: 1
                                    value: model.progress

                                    background: Rectangle {
                                        radius: 4
                                        color: active ? "#4caf50" : "#e0e0e0"
                                    }

                                    contentItem: Rectangle {
                                        color: "#2196f3"
                                        radius: 4
                                        width: parent.width * value
                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

}
