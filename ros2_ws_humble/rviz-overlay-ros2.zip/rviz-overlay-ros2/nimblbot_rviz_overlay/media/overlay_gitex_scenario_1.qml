import QtQuick 2.3
import QtQuick.Layouts 1.10
import Ros2 1.0
import QtQuick.Controls 2.12
import QtQuick.Controls.Material 2.2
import QtMultimedia 5.4
import QtGraphicalEffects 1.0
import QtQuick.Dialogs 1.3

Item {
  id: page
  width: 1
  height: 1

  Connections {
    target: Ros2
    function onShutdown()
    {
      Qt.quit();
    }
  }


  function pointInTriangle(px, py, ax, ay, bx, by, cx, cy)
  {
    function area(x1, y1, x2, y2, x3, y3)
    {
      return Math.abs(x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2)) / 2.0;
    }

    var A = area(ax, ay, bx, by, cx, cy);
    var A1 = area(px, py, bx, by, cx, cy);
    var A2 = area(ax, ay, px, py, cx, cy);
    var A3 = area(ax, ay, bx, by, px, py);

    var epsilon = 0.00001;
    return Math.abs((A1 + A2 + A3) - A) < epsilon;
  }

  function updateSelection_checkbox_tf()
  {
    let dx = checkbox_linear_x.checked ? 1.0 : 0.0;
    let dy = checkbox_linear_y.checked ? 1.0 : 0.0;
    let dz = checkbox_linear_z.checked ? 1.0 : 0.0;
    let ax = checkbox_angular_x.checked ? 1.0 : 0.0;
    let ay = checkbox_angular_y.checked ? 1.0 : 0.0;
    let az = checkbox_angular_z.checked ? 1.0 : 0.0;

    sendTwist(dx, dy, dz, ax, ay, az);

  }

  function sendTwist(x, y, z, roll, pitch, yaw)
  {
    change_control_interactive_marker.publish({
    linear: {
      x: x,
      y: y,
      z: z
    },
    angular: {
      x: roll,
      y: pitch,
      z: yaw
    }
  })
}



property var change_control_mode: Ros2.createPublisher("/nb/change_control_mode", "std_msgs/msg/Int8", 10)
property var motor_lock: Ros2.createPublisher("/nb/motor_lock", "std_msgs/msg/Int32MultiArray", 10)
property var playback_pub: Ros2.createPublisher("/nb/play_back_overlay", "std_msgs/msg/String", 10)
property var change_scale_interactive_marker: Ros2.createPublisher("/interactive_tf_controller_EE/scale", "std_msgs/msg/Float32", 10)
property var change_control_interactive_marker: Ros2.createPublisher("/interactive_tf_controller_EE/control", "geometry_msgs/msg/Twist", 10)
property var yaml_trajectory_pub: Ros2.createPublisher("/nb/yaml_path_file", "std_msgs/msg/String", 10)

Subscription {
  id: status_command_multiple
  topic: "/nb/status_command_multiple"
  onNewMessage: desired_control_mode.external_refresh = message.data
}

Subscription {
  id: status_play_back
  topic: "/nb/play_back_state"
  onNewMessage: {
    var datas = message.data.split(";")

    playback_loop.loop = datas[2].split("=")[1] === 'True'
    speedSlider.value = datas[1].split("=")[1]
    playback_param_Window.selectedFolder = datas[0].split("=")[1].slice(0, -1)

    if (playback_param_Window.selectedFolder === '')
    {
      playback_start.visible = false
      playback_stop.visible = false
      playback_pause.visible = false
      playback_loop.visible = false
    }
    else {
      playback_start.visible = datas[3].split("=")[1] === 'pause'
      playback_pause.visible = datas[3].split("=")[1] === 'play'
      playback_loop.visible = true
      playback_stop.visible = true
    }
  }
}


Subscription {
  id: status_driver_circular_carrier
  topic: "/circular_carrier/status_driver"
  onNewMessage: {
    var devs = message.devices.toArray()
    battery_level._rawPourcentage = 100 * (devs[0].voltage_logic - (3.2 * 6)) / ((4.2 - 3.2) * 6)
  }
}


// Subscription {
//   id: status_motor_lock
//   topic: "/nb/motor_lock"
//   onNewMessage: {
//     floatingWindow.module_lock_topic = message.data.toArray();
//   }
// }

Subscription {
  id: status_interactive_marker
  topic: "/interactive_tf_controller_EE/status"
  onNewMessage: {
    slider_interactive_marker_cartesian.value = message.data;
  }
}

Frame {
  id: principal_frame
  width: 300
  height: 300
  padding: 20
  background: Rectangle {
    color: "transparent"
    border.width: 0
  }

  Column {
    anchors.fill: parent
    spacing: 10

    ComboBox {
      id: desired_control_mode
      anchors.horizontalCenter: parent.horizontalCenter
      property int external_refresh: -1
        width: 230
        height: 50
        textRole: "text"
        background: Rectangle {
          radius: 4
          border.color: "#000000"
          border.width: 2
        }
        model: ListModel {
          ListElement {
            text: "Pause"
            icon: "qrc:/pause.png"
            cmd: 0
          }
          ListElement {
            text: "Cartesian"
            icon: "qrc:/cartesian.png"
            cmd: 1
          }
          // ListElement {
          //   text: "Modulaire"
          //   icon: "qrc:/modular.png"
          //   cmd: 2
          // }
          ListElement {
            text: "Path Follow"
            icon: "qrc:/path_follow.png"
            cmd: 3
          }
          // ListElement {
          //   text: "Planification"
          //   icon: "qrc:/cartesian.png"
          //   cmd: 4
          // }
          // ListElement {
          //   text: "Scout"
          //   icon: "qrc:/scout.png"
          //   cmd: 5
          // }
          ListElement {
            text: "Playback"
            icon: "qrc:/playback.png"
            cmd: 6
          }
        }

        delegate: ItemDelegate {
          width: parent.width
          contentItem: Row {
            spacing: 8
            Image {
              source: model.icon
              width: 30
              height: 30
              fillMode: Image.PreserveAspectFit
              verticalAlignment: Text.AlignVCenter
              anchors.verticalCenter: parent.verticalCenter
            }
            Text {
              text: model.text
              font.pixelSize: 20
              font.bold: true
              color: "#000000"
              verticalAlignment: Text.AlignVCenter
              anchors.verticalCenter: parent.verticalCenter
            }
          }
          highlighted: ListView.isCurrentItem
        }

        contentItem: Row {
          spacing: 8
          anchors.fill: parent
          anchors.margins: 4
          Image {
            id: currentIcon
            width: 30
            height: 30
            fillMode: Image.PreserveAspectFit
            verticalAlignment: Text.AlignVCenter
            anchors.top: parent.top
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            source: desired_control_mode.currentIndex >= 0 ? desired_control_mode.model.get(desired_control_mode.currentIndex).icon : ""
          }
          Text {
            id: currentText
            font.pixelSize: 20
            font.bold: true
            color: "#000000"
            text: desired_control_mode.currentText
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            horizontalAlignment: Text.AlignHCenter
            anchors.verticalCenter: parent.verticalCenter
            anchors.top: parent.top
            anchors.leftMargin: 45
          }
        }

        onExternal_refreshChanged: {
        for (var i = 0; i < desired_control_mode.model.count; i++) {
          if (desired_control_mode.model.get(i).cmd === external_refresh)
          {
            currentIndex = i
          }
        }
      }

      onCurrentIndexChanged: {

        if (desired_control_mode.model.get(currentIndex).cmd != external_refresh)
        {
          page.change_control_mode.publish({data: desired_control_mode.model.get(desired_control_mode.currentIndex).cmd});
        }


        //Cartesian mode
        if (desired_control_mode.model.get(desired_control_mode.currentIndex).text == 'Cartesian')
        {
          cartesian_param_Window.visible = true;
          cartesian_param_Window.canvasesVisible = false;
          cartesian_param_Window.height = 30;
        }
        else {
          cartesian_param_Window.visible = false;
          cartesian_param_Window.canvasesVisible = false;
        }
        if (desired_control_mode.model.get(desired_control_mode.currentIndex).text == 'Playback')
        {
          playback_param_Window.visible = true;
        }
        else {
          playback_param_Window.visible = false;
        }
      }
    }

    Rectangle {
      id: button
      width: 180
      height: 180
      radius: width / 2
      color: "#d32f2f"  // Rouge vif
      border.color: "#eeeeee"
      border.width: 6
      antialiasing: true
      anchors.horizontalCenter: parent.horizontalCenter

      property bool pressed: true
        signal emergencyStop

        // Ombre portée sous le bouton
        layer.enabled: true
        layer.effect: DropShadow {
          anchors.fill: button
          radius: 20
          samples: 32
          horizontalOffset: 0
          verticalOffset: 8
          color: "#66000000"
        }

        // Effet de relief (biseautage simulé)
        Rectangle {
          anchors.fill: parent
          radius: width / 2
          color: "transparent"
          border.color: "#ff7979"
          border.width: 3
          layer.enabled: true
          layer.effect: InnerShadow {
            radius: 10
            samples: 32
            color: "#55000000"
            horizontalOffset: 0
            verticalOffset: 3
            spread: 0.5
          }
        }

        // Le bouton rouge "physique" avec effet d’enfoncement
        Rectangle {
          id: topButton
          anchors.centerIn: parent
          width: parent.width * 0.85
          height: parent.height * 0.85
          radius: width / 2
          color: button.pressed ? "#a12727" : "#e53935"
          border.color: button.pressed ? "#7a1f1f" : "#ff9999"
          border.width: 4
          antialiasing: true
          scale: button.pressed ? 0.95 : 1.0
          Behavior on scale {
          NumberAnimation {
            duration: 120
            easing.type: Easing.OutQuad
          }
        }
      }

      Text {
        anchors.centerIn: parent
        text: "STOP"
        font.pixelSize: 50
        font.bold: true
        color: "yellow"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        z: 1
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        opacity: button.pressed ? 0.7 : 1.0
      }

      MouseArea {
        anchors.fill: parent
        onPressed: button.pressed = true
        onReleased: {
          if (button.pressed)
          {
            button.pressed = false;
            desired_control_mode.currentIndex = 0;
            button.emergencyStop();
          }
        }
        cursorShape: Qt.PointingHandCursor
      }

    }


    // Text {
    //   id: battery_text
    //   anchors.horizontalCenter: parent.horizontalCenter
    //   font.pixelSize: 32

    //     text: "Battery : " + pourcentage + " %"

    //     color: {
    //       if (pourcentage < 20) return "red"
    //       else if (pourcentage < 50) return "orange"
    //         else return "green"
    //         }
    //       }

  }

  // Rectangle {
  //   id: floatingWindow
  //   width: 300
  //   x: 0
  //   y: 300
  //   color: "#f0f0f0"
  //   radius: 10
  //   border.color: "#666"
  //   border.width: 2
  //   visible: true

  //   property bool canvasesVisible: false
  //     property int num_module: 12
  //       property var module_active: (function() {
  //         var arr = [];
  //         for (var i = 0; i < num_module * 2 + 1; i++) {
  //           arr.push(true);
  //         }
  //         return arr;
  //       })()

  //       property var module_lock_topic: [];

  //         height: 30

  //         Column {
  //           anchors.fill: parent

  //           Rectangle {
  //             id: titleBar
  //             width: parent.width
  //             height: 30
  //             color: "#444"
  //             radius: 10

  //             Text {
  //               text: "Configuration Robot"
  //               anchors.centerIn: parent
  //               color: "white"
  //             }

  //             MouseArea {
  //               anchors.fill: parent
  //               drag.target: floatingWindow
  //               drag.axis: Drag.XAndYAxis
  //               cursorShape: Qt.OpenHandCursor
  //               onPressed: cursorShape = Qt.ClosedHandCursor
  //               onReleased: cursorShape = Qt.OpenHandCursor
  //               onClicked: {
  //                 if (floatingWindow.height === 30)
  //                 {
  //                   floatingWindow.height = floatingWindow.num_module * 60 + 150;
  //                   floatingWindow.canvasesVisible = true;
  //                 } else {
  //                 floatingWindow.height = 30;
  //                 floatingWindow.canvasesVisible = false;
  //               }
  //             }
  //           }
  //         }

  //         Item {
  //           height: 10
  //           width: parent.width
  //           visible: floatingWindow.canvasesVisible
  //         }


  //         Canvas {
  //           id :wrist
  //           width: 60
  //           height: 50
  //           visible: floatingWindow.canvasesVisible
  //           anchors.horizontalCenter: parent.horizontalCenter
  //           // anchors.horizontalCenter: parent.horizontalCenter

  //           onPaint: {
  //             var ctx = getContext("2d");
  //             ctx.clearRect(0, 0, width, height);

  //             ctx.beginPath();
  //             ctx.moveTo(0, 0);
  //             ctx.lineTo(width, 0);
  //             ctx.lineTo(width, height);
  //             ctx.lineTo(0, height);
  //             ctx.closePath();
  //             ctx.fillStyle = floatingWindow.module_active[2 * floatingWindow.num_module] ? "gray" : "red";
  //             ctx.fill();

  //             ctx.lineWidth = 3;
  //             ctx.strokeStyle = "#000000";
  //             ctx.stroke();
  //           }

  //           MouseArea {
  //             anchors.fill: parent
  //             onClicked: {
  //               floatingWindow.module_active[2 * floatingWindow.num_module] = !floatingWindow.module_active[2 * floatingWindow.num_module]
  //               wrist.requestPaint();

  //               var motor_lock_list = [];
  //               for (var i = 0; i < 2*floatingWindow.num_module + 1; i++) {
  //                 if (!floatingWindow.module_active[i])
  //                 {
  //                   motor_lock_list.push(i)
  //                 }
  //               }

  //               page.motor_lock.publish({data: motor_lock_list});

  //             }
  //           }

  //         }


  //         Repeater {
  //           id : repeater
  //           model: floatingWindow.num_module

  //           Canvas {
  //             id :triangleCanvas
  //             width: 60
  //             height: 60
  //             visible: floatingWindow.canvasesVisible
  //             anchors.horizontalCenter: parent.horizontalCenter
  //             // anchors.horizontalCenter: parent.horizontalCenter

  //             onPaint: {
  //               var ctx = getContext("2d");
  //               ctx.clearRect(0, 0, width, height);

  //               ctx.beginPath();
  //               ctx.moveTo(0, 0);
  //               ctx.lineTo(width, 0);
  //               ctx.lineTo(width, height * 0.8);
  //               ctx.lineTo(0, height * 0.2);
  //               ctx.closePath();
  //               ctx.fillStyle = floatingWindow.module_active[2 * (floatingWindow.num_module - index - 1) + 1] ? "gray" : "red";
  //               ctx.fill();

  //               ctx.lineWidth = 3;
  //               ctx.strokeStyle = "#000000";
  //               ctx.stroke();

  //               ctx.beginPath();
  //               ctx.moveTo(0, height * 0.2);
  //               ctx.lineTo(0, height);
  //               ctx.lineTo(width, height);
  //               ctx.lineTo(width, height * 0.8);
  //               ctx.closePath();
  //               ctx.fillStyle = floatingWindow.module_active[2 * (floatingWindow.num_module - index - 1)] ? "gray" : "red";
  //               ctx.fill();

  //               ctx.lineWidth = 3;
  //               ctx.strokeStyle = "#000000";
  //               ctx.stroke();
  //             }

  //             MouseArea {
  //               anchors.fill: parent
  //               onClicked: (mouse) => {
  //               const x = mouse.x;
  //               const y = mouse.y;
  //               var motor_desired = 2 * (floatingWindow.num_module - index - 1);
  //               if (y <= height * 0.2)
  //               {
  //                 motor_desired = 2 * (floatingWindow.num_module - index - 1) + 1;
  //               }
  //               else if(y >= height * 0.8)
  //               {
  //                 motor_desired = 2 * (floatingWindow.num_module - index - 1);
  //               }
  //               else if (pointInTriangle(x, y - height * 0.2, 0, 0, width, 0, width, height * 0.6))
  //               {
  //                 motor_desired = 2 * (floatingWindow.num_module - index - 1) + 1;
  //               }

  //               floatingWindow.module_active[motor_desired] = !floatingWindow.module_active[motor_desired]
  //               // triangleCanvas.requestPaint();

  //               var motor_lock_list = [];
  //               for (var i = 0; i < 2*floatingWindow.num_module + 1; i++) {
  //                 if (!floatingWindow.module_active[i])
  //                 {
  //                   motor_lock_list.push(i)
  //                 }
  //               }
  //               page.motor_lock.publish({data: motor_lock_list});
  //             }
  //           }

  //         }
  //       }

  //       Item {
  //         height: 10
  //         width: parent.width
  //         visible: floatingWindow.canvasesVisible
  //       }

  //       Button {
  //         text: "Réinitialiser"
  //         visible: floatingWindow.canvasesVisible
  //         anchors.horizontalCenter: parent.horizontalCenter
  //         background: Rectangle {
  //           implicitWidth: 200
  //           implicitHeight: 40
  //           color: "#444"
  //           radius: 8
  //         }
  //         contentItem: Text {
  //           text: parent.text
  //           anchors.centerIn: parent
  //           verticalAlignment: Text.AlignVCenter
  //           horizontalAlignment: Text.AlignHCenter
  //           color: "white"
  //         }
  //         onClicked: {
  //           page.motor_lock.publish({data: []});
  //         }
  //       }
  //     }

  //     onModule_lock_topicChanged: {
  //     for (var i = 0; i < floatingWindow.module_active.length; i++) {
  //       floatingWindow.module_active[i] = true
  //     }
  //     for (var i = 0; i < module_lock_topic.length; i++) {
  //       let idx = module_lock_topic[i];
  //       if (idx >= 0 && idx < floatingWindow.module_active.length)
  //       {
  //         floatingWindow.module_active[idx] = false;
  //       }
  //     }
  //     for (var i = 0; i < repeater.count; i++) {
  //       repeater.itemAt(i).requestPaint();
  //       wrist.requestPaint();
  //     }
  //   }
  // }


  Rectangle {
    id: cartesian_param_Window
    width: 300
    x: 0
    y: principal_frame.height
    color: "#f0f0f0"
    radius: 10
    border.color: "#666"
    border.width: 2
    visible: true
    property bool canvasesVisible: false

      Column {
        anchors.fill: parent

        Rectangle {
          id: cartesian_tilte
          width: parent.width
          height: 30
          color: "#444"
          radius: 5

          Text {
            text: "Configuration"
            anchors.centerIn: parent
            color: "white"
            font.pixelSize : 24
            font.bold: true
          }

          MouseArea {
            anchors.fill: parent
            drag.target: cartesian_param_Window
            drag.axis: Drag.XAndYAxis
            cursorShape: Qt.OpenHandCursor
            onPressed: cursorShape = Qt.ClosedHandCursor
            onReleased: cursorShape = Qt.OpenHandCursor
            onClicked: {
              if (cartesian_param_Window.height === 30)
              {
                cartesian_param_Window.height = 360;
                cartesian_param_Window.canvasesVisible = true;
              } else {
              cartesian_param_Window.height = 30;
              cartesian_param_Window.canvasesVisible = false;
            }
          }
        }
      }

      Item {
        height: 10
        width: parent.width
        visible: cartesian_param_Window.canvasesVisible
      }

      Text {
        text: "Interactive Marker"
        anchors.horizontalCenter: parent.horizontalCenter
        visible: cartesian_param_Window.canvasesVisible
        font.pixelSize: 24
        color: "black"
        font.bold: true
      }

      Slider {
        id: slider_interactive_marker_cartesian
        from: 0.0
        to: 0.5
        value: 0.1
        stepSize: 0.01
        orientation: Qt.Horizontal
        width: parent.width - 50
        visible: cartesian_param_Window.canvasesVisible
        anchors.horizontalCenter: parent.horizontalCenter


        onValueChanged: {
          page.change_scale_interactive_marker.publish({data: value});
        }
      }


      Item {
        height: 10
        width: parent.width
        visible: cartesian_param_Window.canvasesVisible
      }

      Row {
        id: linear_tf
        spacing: 10
        visible: cartesian_param_Window.canvasesVisible
        anchors.horizontalCenter: parent.horizontalCenter

        Text {
          text: "Linear : "
          color: "black"
          anchors.verticalCenter: parent.verticalCenter
        }

        CheckBox {
          id: checkbox_linear_x
          text: "X"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
        CheckBox {
          id: checkbox_linear_y
          text: "Y"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
        CheckBox {
          id: checkbox_linear_z
          text: "Z"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
      }

      Item {
        height: 10
        width: parent.width
        visible: cartesian_param_Window.canvasesVisible
      }

      Row {
        id: angular_tf
        spacing: 10
        visible: cartesian_param_Window.canvasesVisible
        anchors.horizontalCenter: parent.horizontalCenter

        Text {
          text: "Angular : "
          color: "black"
          anchors.verticalCenter: parent.verticalCenter
        }

        CheckBox {
          id: checkbox_angular_x
          text: "X"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
        CheckBox {
          id: checkbox_angular_y
          text: "Y"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
        CheckBox {
          id: checkbox_angular_z
          text: "Z"
          checked: true
          onCheckedChanged: updateSelection_checkbox_tf()
        }
      }

      Item {
        height: 30
        width: parent.width
        visible: cartesian_param_Window.canvasesVisible
      }

      Text {
        text: "Trajectory"
        anchors.horizontalCenter: parent.horizontalCenter
        visible: cartesian_param_Window.canvasesVisible
        font.pixelSize: 24
        color: "black"
        font.bold: true
      }

      Item {
        height: 10
        width: parent.width
        visible: cartesian_param_Window.canvasesVisible
      }

      Row {
        id: trajectory_row_setting
        spacing: 10
        visible: cartesian_param_Window.canvasesVisible
        anchors.horizontalCenter: parent.horizontalCenter
        property string selectedyamltraj: ""
          property var parts_file: trajectory_row_setting.selectedyamltraj.split("/")

          ToolButton {
            id: trajectory_yaml_button
            icon.name: "document"
            width: 48
            height: 48
            visible: cartesian_param_Window.canvasesVisible
            onClicked: {
              fileDialog_yaml.open()
            }
            background: Rectangle {
              anchors.fill: parent
              color: "white"
              radius: width / 10
              border.color: "#888"
              border.width: 1
            }
          }


          ToolButton {
            id: send_yaml
            icon.name: "media-playback-start"
            width: 48
            height: 48
            visible: cartesian_param_Window.canvasesVisible && trajectory_row_setting.selectedyamltraj !== ""
            onClicked: {
              yaml_trajectory_pub.publish({data: ''});
              yaml_trajectory_pub.publish({data: trajectory_row_setting.selectedyamltraj});
            }
            background: Rectangle {
              anchors.fill: parent
              color: "white"
              radius: width / 10
              border.color: "#888"
              border.width: 1
            }
          }

          ToolButton {
            id: delete_yaml
            icon.name: "dialog-close"
            width: 48
            height: 48
            visible: cartesian_param_Window.canvasesVisible
            onClicked: {
              yaml_trajectory_pub.publish({data: ''});
            }
            background: Rectangle {
              anchors.fill: parent
              color: "white"
              radius: width / 10
              border.color: "#888"
              border.width: 1
            }
          }

          FileDialog {
            id: fileDialog_yaml
            title: "Sélectionnez un fichier YAML"
            nameFilters: ["Fichiers YAML (*.yaml *.yml)"]
            selectFolder: false
            onAccepted: {
              trajectory_row_setting.selectedyamltraj = fileDialog_yaml.fileUrl
              console.log("YAML choisi:", fileDialog_yaml.fileUrl)
            }
            onRejected: {
              console.log("Sélection annulée")
            }
          }

        }

        Item {
          height: 10
          width: parent.width
          visible: cartesian_param_Window.canvasesVisible
        }

        Text {
          visible: cartesian_param_Window.canvasesVisible
          anchors.horizontalCenter: parent.horizontalCenter
          text: trajectory_row_setting.parts_file[trajectory_row_setting.parts_file.length - 1]
        }

      }

    }
  }


  Rectangle {
    id: playback_param_Window
    height:220
    width: 300
    x: 20
    y: 350
    color: "#f0f0f0"
    radius: 10
    border.color: "#666"
    border.width: 2
    visible: false
    property string selectedFolder: ""
      property var parts: playback_param_Window.selectedFolder.split("/")

      MouseArea {
        anchors.fill: parent
        drag.target: playback_param_Window
        drag.axis: Drag.XAndYAxis
        cursorShape: Qt.OpenHandCursor
        onPressed: cursorShape = Qt.ClosedHandCursor
        onReleased: cursorShape = Qt.OpenHandCursor
      }

      Column {
        anchors.fill: playback_param_Window
        spacing: 20
        property bool loop: true

          Item {
            height: 10
            width:200
            visible: true

          }


          Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 5
            x: 40
            y: 400

            ToolButton {
              id: playback_folder
              icon.name: "folder"
              width: 48
              height: 48
              visible: true
              onClicked: {
                page.playback_pub.publish({data: "loop=false"});
                page.playback_pub.publish({data: "state=restart"});
                folderDialog.open()
              }
              background: Rectangle {
                anchors.fill: parent
                color: "white"
                radius: width / 10
                border.color: "#888"
                border.width: 1
              }
            }

            ToolButton {
              id: playback_start
              icon.name: "media-playback-start"
              width: 48
              height: 48
              visible: false
              onClicked: {
                playback_start.visible = false
                playback_pause.visible = true
                page.playback_pub.publish({data: "state=play"});
              }
              background: Rectangle {
                anchors.fill: parent
                color: "white"
                radius: width / 10
                border.color: "#888"
                border.width: 1
              }
            }

            ToolButton {
              id: playback_pause
              icon.name: "media-playback-pause"
              width: 48
              height: 48
              visible: false
              onClicked: {
                playback_start.visible = true
                playback_pause.visible = false
                page.playback_pub.publish({data: "state=pause"});
              }
              background: Rectangle {
                anchors.fill: parent
                color: "white"
                radius: width / 10
                border.color: "#888"
                border.width: 1
              }
            }


            ToolButton {
              id: playback_stop
              icon.name: "media-playback-stop"
              width: 48
              height: 48
              visible: false
              onClicked: {
                page.playback_pub.publish({data: "state=restart"});
                playback_start.visible = true
                playback_pause.visible = false

                page.playback_pub.publish({data: "loop=false"});
              }
              background: Rectangle {
                anchors.fill: parent
                color: "white"
                radius: width / 10
                border.color: "#888"
                border.width: 1
              }
            }

            ToolButton {
              id: playback_loop
              icon.name: "view-refresh"
              width: 48
              height: 48
              visible: false
              property bool loop: false
                onClicked: {
                  playback_loop.loop = !playback_loop.loop
                  page.playback_pub.publish({data: "loop=" + playback_loop.loop});
                }
                background: Rectangle {
                  anchors.fill: parent
                  color: playback_loop.loop ? "green" : "white"
                  radius: width / 10
                  border.color: "#888"
                  border.width: 1
                }
              }
            }

            Text {
              anchors.horizontalCenter: parent.horizontalCenter
              text: playback_param_Window.parts[playback_param_Window.parts.length - 1]
            }

            Column {
              spacing: 0
              anchors.horizontalCenter: parent.horizontalCenter

              Slider {
                id: speedSlider
                from: 0.0
                to: 2.0
                value: 1.0
                stepSize: 0.1
                width: 250
                onValueChanged: {
                  page.playback_pub.publish({data: "rate=" + value});
                }
              }

              Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: "Vitesse de lecture: " + speedSlider.value.toFixed(1) + "x" }
              }

              FileDialog {
                id: folderDialog
                title: "Sélectionnez un dossier"
                selectFolder: true
                onAccepted: {
                  playback_param_Window.selectedFolder = folderDialog.fileUrl
                  console.log("Dossier choisi:", playback_param_Window.selectedFolder)
                  page.playback_pub.publish({data: "path=" + playback_param_Window.selectedFolder});
                  playback_loop.visible = true
                  playback_start.visible = true
                  playback_stop.visible = true
                }
                onRejected: {
                  console.log("Sélection annulée")
                }
              }






            }



          }

          Item {
            id: battery_level
            width: 300
            height: 180
            y:-40
            x : 250
            property int _rawPourcentage: 0
              property int pourcentage: Math.min(100, Math.max(0, _rawPourcentage))

              // image de batterie
              Image {
                id: batteryImg
                source: "qrc:/battery.png"
                anchors.fill: parent
                fillMode: Image.PreserveAspectFit
              }

              Rectangle {
                id: fillRect_back
                x: 77
                y: 118 - 60
                height:64
                radius : 5
                width: 132
                color: "white"
              }

              Rectangle {
                id: fillRect
                x: 80
                y: 121 - 60
                height:58
                radius : 5
                width: 125 * (battery_level.pourcentage / 100.0)
                color: battery_level.pourcentage > 20 ? "green" : "red"
                z: 1
              }

              Text {
                anchors.centerIn: parent
                text: battery_level.pourcentage + "%"
                font.pixelSize: 32
                color: "black"
                font.bold: true
                z: 2
              }


            }



            // ImageTransportSubscription {
            //   id: imageSubscription
            //   topic: combo_box_topic_name.currentText
            //   defaultTransport: "raw"
            // }


            Rectangle {
              id: camera_layout
              width: 1
              height: 1
              color: "black"
              border.color: "white"
              border.width: 1

              Loader {
                id: imageLoader
                sourceComponent: imageComponent
              }

              Component {
                id: imageComponent

                ImageTransportSubscription {
                  id: imageSubscription
                  topic: combo_box_topic_name.currentText
                  defaultTransport: "raw"
                }
              }



              VideoOutput {
                id: video_layout
                source: imageLoader.item
                orientation: 0
                x: 600
                y: 300


                MouseArea {
                  anchors.fill: parent
                  drag.target: video_layout
                  drag.axis: Drag.XAndYAxis
                  cursorShape: Qt.OpenHandCursor
                  hoverEnabled: true
                  onPressed: {
                    cursorShape = Qt.ClosedHandCursor
                    border_rectangle.visible=true
                  }
                  onReleased: {
                    cursorShape = Qt.OpenHandCursor
                    border_rectangle.visible=false
                  }

                  onEntered: {
                    parameter_icon.visible = false
                    parameter_window.visible = false
                    resizeHandle.visible = true
                  }

                  onExited: {
                    parameter_icon.visible = false
                    parameter_window.visible = false
                    combo_box_topic_name.visible=false
                    parameter_icon.visible = false
                    close_icon.visible = false
                    anchor_icon.visible = false
                    resizeHandle.visible = false
                  }

                }

                Rectangle {
                  id: border_rectangle
                  width: parent.width
                  height: parent.height
                  anchors.left: video_layout.left
                  anchors.top: video_layout.top
                  color: "transparent"
                  border.color: "green"
                  border.width:5
                  radius: 4
                  visible: false

                }

                Rectangle {
                  id: parameter_window
                  width : Math.max(100, video_layout.width)
                  height : Math.max(10, 100 / (video_layout.width / video_layout.height))
                  anchors.top: video_layout.top
                  anchors.horizontalCenter: parent.horizontalCenter
                  color: "#000000"
                  opacity:0.3
                  visible: false
                }

                Row {
                  spacing: 10  // espace entre les textes
                  anchors.centerIn: parameter_window


                  ComboBox {
                    id: combo_box_topic_name
                    width: 200
                    model: ["/camera/camera/color/image_rect_raw"] //, "/camera/image_raw", "/webcam/image"]
                    visible: false
                    onCurrentTextChanged: {
                      imageLoader.sourceComponent = null
                      imageLoader.sourceComponent = imageComponent
                    }
                  }

                  Text {
                    id : parameter_icon
                    verticalAlignment: Text.AlignVCenter
                    horizontalAlignment: Text.AlignHCenter
                    text: "\uf013"
                    font.family: "Font Awesome 5 Free"
                    font.pointSize: 1 + parameter_window.height / 2
                    visible: false
                  }

                  Text {
                    id : close_icon
                    verticalAlignment: Text.AlignVCenter
                    horizontalAlignment: Text.AlignHCenter
                    text: "\uf00d"
                    font.family: "Font Awesome 5 Free"
                    font.pointSize: 1 + parameter_window.height / 2
                    visible: false
                  }

                  Text {
                    id : anchor_icon
                    verticalAlignment: Text.AlignVCenter
                    horizontalAlignment: Text.AlignHCenter
                    text: "\uf13d"
                    font.family: "Font Awesome 5 Free"
                    font.pointSize: 1 + parameter_window.height / 2
                    visible: false
                  }
                }

                Rectangle {
                  id: resizeHandle
                  width: 16
                  height: 16
                  anchors.right: video_layout.right
                  anchors.bottom: video_layout.bottom
                  color: "white"
                  border.color: "black"
                  radius: 4
                  z: 10
                  visible: false

                  MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.SizeFDiagCursor
                    drag.target: parent
                    onPositionChanged: {
                      let ratio = video_layout.width / video_layout.height
                      video_layout.width = Math.max(100, video_layout.width + mouse.x + mouse.y)
                      video_layout.height = video_layout.width / ratio
                      border_rectangle.visible=true
                    }
                    onReleased: {
                      border_rectangle.visible=false
                    }
                  }
                }
              }}




              Component.onCompleted: {
                // Initialize ROS with the given name. The command line args are passed by the plugin
                // Optionally, you can call init with a string list ["arg1", "arg2"] after the name to use those
                // args instead of the ones supplied by the command line.
                Ros2.init("andra_overlay_rviz2");
              }
            }