import QtQuick 2.15
import QtQuick.Controls 2.15

Button {
    id: root

    // Public properties
    property string iconName: ""
    property color iconColor: "black"
    property int iconSize: 48

    width: 64
    height: 64

    background: Rectangle {
        anchors.fill: parent
        color: root.down ? "#e0e0e0" : "white"
        radius: width / 10
        border.color: "#888"
        border.width: 1
    }

    contentItem: Text {
        anchors.centerIn: parent
        text: root.iconName
        font.family: "Material Symbols Outlined"
        color: root.iconColor
        font.pixelSize: root.iconSize
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
    }

}
