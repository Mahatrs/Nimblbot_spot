import QtQuick 2.15
import QtQuick.Controls 2.15

Button {
    id: root

    property string iconName: ""
    property color bgColor: "white"
    property color iconColor: "black"
    property color pressedColor: "#e0e0e0"
    property int iconSize: 24

    width: 40
    height: 40

    background: Rectangle {
        anchors.fill: parent
        color: root.down ? pressedColor : root.bgColor
        radius: width / 10
        border.color: "transparent"
        border.width: 1
    }

    contentItem: Text {
        anchors.centerIn: parent
        text: root.iconName
        font.family: "Material Symbols Outlined"
        color: root.iconColor
        font.pixelSize: root.iconSize
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
    }

}
