import QtQuick 2.3
import QtQuick.Layouts 1.10
import Ros2 1.0
import QtQuick.Controls 2.12
import QtQuick.Controls.Material 2.2
import QtMultimedia 5.4
import QtGraphicalEffects 1.0

Item {
    id: page
    width: 1
    height: 1

    Connections {
        target: Ros2
        function onShutdown() {
            Qt.quit();
        }
    }

    property var selected_mode: Ros2.createPublisher("/nb/change_control_mode", "std_msgs/msg/Int8", 10)

    Subscription {
        id: status_command_multiple
        topic: "/nb/status_command_multiple"
        onNewMessage: desired_control_mode.external_refresh = message.data
    }

    Frame {
        id: principal_frame
        width: 300
        height: 300
        padding: 20
        background: Rectangle {
            color: "transparent"
            border.width: 0 
        }

        Column {
            anchors.fill: parent
            spacing: 10

            ComboBox {
                id: desired_control_mode
                property int external_refresh: -1
                width: 230
                height: 50
                textRole: "text"
                background: Rectangle {
                    radius: 4
                    border.color: "#000000"
                    border.width: 2
                }
                model: ListModel {
                    ListElement {
                        text: "Pause"
                        icon: "qrc:/pause.png"
                    }
                    ListElement {
                        text: "Cartésien"
                        icon: "qrc:/cartesian.png"
                    }
                    ListElement {
                        text: "Modulaire"
                        icon: "qrc:/modular.png"
                    }
                    ListElement {
                        text: "Suivi de chemin"
                        icon: "qrc:/path-follow.png"
                    }
                }

                delegate: ItemDelegate {
                    width: parent.width
                    contentItem: Row {
                        spacing: 8
                        Image {
                            source: model.icon
                            width: 30
                            height: 30
                            fillMode: Image.PreserveAspectFit
                            verticalAlignment: Text.AlignVCenter
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: model.text
                            font.pixelSize: 20
                            font.bold: true
                            color: "#000000"
                            verticalAlignment: Text.AlignVCenter
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    highlighted: ListView.isCurrentItem
                }

                contentItem: Row {
                    spacing: 8
                    anchors.fill: parent
                    anchors.margins: 4
                    Image {
                        id: currentIcon
                        width: 30
                        height: 30
                        fillMode: Image.PreserveAspectFit
                        verticalAlignment: Text.AlignVCenter
                        anchors.top: parent.top
                        anchors.leftMargin: 10
                        anchors.verticalCenter: parent.verticalCenter
                        source: desired_control_mode.currentIndex >= 0 ? desired_control_mode.model.get(desired_control_mode.currentIndex).icon : ""
                    }
                    Text {
                        id: currentText
                        font.pixelSize: 20
                        font.bold: true
                        color: "#000000"
                        text: desired_control_mode.currentText
                        elide: Text.ElideRight
                        verticalAlignment: Text.AlignVCenter
                        horizontalAlignment: Text.AlignHCenter
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.top: parent.top
                        anchors.leftMargin: 45
                    }
                }

                onExternal_refreshChanged: {
                    currentIndex = external_refresh;
                }

                onCurrentIndexChanged: {
                    if (external_refresh != currentIndex) {
                        page.selected_mode.publish({
                            data: currentIndex
                        });
                    }
                }
            }

            //   Material.theme: Material.Light   // Ou Material.Dark
            //   Material.accent: Material.Blue   // Couleur principale

            //     Column {
            //         anchors.centerIn: parent
            //         spacing: 20

            //         Text {
            //             id: label
            //             font.pixelSize: 24
            //             text: switch1.checked ? "🟢 Activé" : "🔴 Désactivé"
            //             color: switch1.checked ? Material.accent : "gray"
            //         }

            //         Switch {
            //             id: switch1
            //             checked: false
            //             text: "Activer la fonction"
            //             onCheckedChanged: console.log("Switch Material:", checked)
            //         }
            //     }

            //     Column {
            //         anchors.centerIn: parent
            //         visible: progressBar.value >= progressBar.to ?
            //         spacing: 20
            //         width: 300

            //         Text {
            //             text: "Chargement en cours…"
            //             font.pixelSize: 18
            //             horizontalAlignment: Text.AlignHCenter
            //             width: parent.width
            //         }

            //         ProgressBar {
            //             id: progressBar
            //             from: 0
            //             to: 100
            //             value: 40   // Modifie cette valeur pour changer l’avancement
            //             width: parent.width
            //             height: 20
            //         }

            //         Button {
            //             text: "Augmenter"
            //             onClicked: {
            //                 if (progressBar.value < progressBar.to) {
            //                     progressBar.value += 10
            //                 }
            //                 else{
            //                     progressBar.value = progressBar.to
            //                 }
            //             }
            //         }
            //     }
        }
            Rectangle {
                id: floatingWindow
                width: 300
                height: 200
                color: "#f0f0f0"
                radius: 10
                border.color: "#666"
                border.width: 2
                visible: true

                // Barre de titre (clic et drag ici)
                Rectangle {
                    id: titleBar
                    width: parent.width
                    height: 30
                    color: "#444"
                    radius: 10

                    Text {
                        text: "Fenêtre flottante"
                        color: "white"
                        anchors.centerIn: parent
                        font.pixelSize: 16
                    }

                    MouseArea {
                        anchors.fill: parent
                        drag.target: floatingWindow
                        drag.axis: Drag.XAndYAxis
                        cursorShape: Qt.OpenHandCursor
                        onPressed: cursorShape = Qt.ClosedHandCursor
                        onReleased: cursorShape = Qt.OpenHandCursor
                    }
                }

                Repeater {
                    model: 4
                    Canvas {
                        anchors.fill: parent
                        onPaint: {
                            var ctx = getContext("2d");
                            // ctx.clearRect(0, 0, width, height);

                            // Dessin d’un triangle en haut à gauche
                            ctx.beginPath();
                            ctx.moveTo(30, 30 * 2);
                            ctx.lineTo(30, 0);
                            ctx.lineTo(30, 30);
                            ctx.closePath();
                            ctx.fillStyle = "red";
                            ctx.fill();

                            // Optionnel : l’autre moitié
                            ctx.beginPath();
                            ctx.moveTo(30 * 2, 0);
                            ctx.lineTo(30 * 2, 30 * 2);
                            ctx.lineTo(30, 30 * 2);
                            ctx.closePath();
                            ctx.fillStyle = "lightgreen";
                            ctx.fill();
                        }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {}
                        }
                    }
                }}

                Rectangle {
                    id: button
                    width: 180
                    height: 180
                    radius: width / 2
                    color: "#d32f2f"  // Rouge vif
                    border.color: "#eeeeee"
                    border.width: 6
                    antialiasing: true

                    property bool pressed: true
                    signal emergencyStop

                    // Ombre portée sous le bouton
                    layer.enabled: true
                    layer.effect: DropShadow {
                        anchors.fill: button
                        radius: 20
                        samples: 32
                        horizontalOffset: 0
                        verticalOffset: 8
                        color: "#66000000"
                    }

                    // Effet de relief (biseautage simulé)
                    Rectangle {
                        anchors.fill: parent
                        radius: width / 2
                        color: "transparent"
                        border.color: "#ff7979"
                        border.width: 3
                        layer.enabled: true
                        layer.effect: InnerShadow {
                            radius: 10
                            samples: 32
                            color: "#55000000"
                            horizontalOffset: 0
                            verticalOffset: 3
                            spread: 0.5
                        }
                    }

                    // Le bouton rouge "physique" avec effet d’enfoncement
                    Rectangle {
                        id: topButton
                        anchors.centerIn: parent
                        width: parent.width * 0.85
                        height: parent.height * 0.85
                        radius: width / 2
                        color: button.pressed ? "#a12727" : "#e53935"
                        border.color: button.pressed ? "#7a1f1f" : "#ff9999"
                        border.width: 4
                        antialiasing: true
                        scale: button.pressed ? 0.95 : 1.0
                        Behavior on scale {
                            NumberAnimation {
                                duration: 120
                                easing.type: Easing.OutQuad
                            }
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "ARRÊT\nD'URGENCE"
                        font.pixelSize: 24
                        font.bold: true
                        color: "yellow"
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        z: 1
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.verticalCenter: parent.verticalCenter
                        opacity: button.pressed ? 0.7 : 1.0
                    }

                    MouseArea {
                        anchors.fill: parent
                        onPressed: button.pressed = true
                        onReleased: {
                            if (button.pressed) {
                                button.pressed = false;
                                desired_control_mode.currentIndex = 0;
                                button.emergencyStop();
                            }
                        }
                        cursorShape: Qt.PointingHandCursor
                    }
                
            }
        
    }
    // Rectangle {
    //     id: light
    //     width: 60
    //     height: 60
    //     radius: width / 2
    //     color: "#66000000"  // fond transparent foncé

    //     // La lumière rouge (cercle intérieur)
    //     Rectangle {
    //         id: glow
    //         anchors.centerIn: parent
    //         width: parent.width * 0.7
    //         height: parent.height * 0.7
    //         radius: width / 2
    //         color: "red"
    //         opacity: 0.0
    //         layer.enabled: true
    //         layer.effect: Glow {
    //             color: "red"
    //             radius: 30
    //             samples: 32
    //         }

    //         // Animation d'opacité (pulse)
    //         SequentialAnimation on opacity {
    //             loops: Animation.Infinite
    //             NumberAnimation { from: 0.0; to: 1.0; duration: 800; easing.type: Easing.InOutQuad }
    //             NumberAnimation { from: 1.0; to: 0.0; duration: 800; easing.type: Easing.InOutQuad }
    //         }
    //     }

    //     // Cercle extérieur (ombre diffuse)
    //     Rectangle {
    //         anchors.centerIn: parent
    //         width: parent.width * 0.9
    //         height: parent.height * 0.9
    //         radius: width / 2
    //         color: "#44000000"
    //     }
    // }

    Component.onCompleted: {
        // Initialize ROS with the given name. The command line args are passed by the plugin
        // Optionally, you can call init with a string list ["arg1", "arg2"] after the name to use those
        // args instead of the ones supplied by the command line.
        Ros2.init("nimblbot_overlay_rviz2");
    }
}
