/*
 * Copyright (C) 2019  Stefan Fabian
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef RVIZ_OVERLAY_ROS_GITEX_1_OVERLAY_DISPLAY_H
#define RVIZ_OVERLAY_ROS_GITEX_1_OVERLAY_DISPLAY_H

#include <hector_rviz_overlay/displays/qml_overlay_display.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp/client.hpp>
#include <rclcpp/service.hpp>
#include <QObject>
#include <std_msgs/msg/string.hpp>
#include <std_srvs/srv/empty.hpp>
#include "std_msgs/msg/int8_multi_array.hpp"
#include <QtQml>

namespace gitex_1_rviz_overlay
{

  class QmlRosGitex1OverlayDisplay : public hector_rviz_overlay::QmlOverlayDisplay
  {
    Q_OBJECT

  Q_SIGNALS:
    void moduleLockTopicChanged(QVariantList lockIndices);

  public:
    QmlRosGitex1OverlayDisplay();
    void onModuleLockTopic(const std_msgs::msg::Int8MultiArray::SharedPtr msg);

  protected:
    QString getPathToQml() override;
  };

}

#endif