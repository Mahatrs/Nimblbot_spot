/*
 * Copyright (C) 2018  Stefan Fabian
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "gitex_demo_rviz_overlay/gitex_demo_overlay_display.hpp"
#include <QFontDatabase>
#include <QDebug>

namespace gitex_demo_rviz_overlay
{
  QmlRosGitexDemoOverlayDisplay::QmlRosGitexDemoOverlayDisplay()
      : hector_rviz_overlay::QmlOverlayDisplay()
  {
    static int materialSymbolsFontId = -1;

    if (materialSymbolsFontId == -1) {
        materialSymbolsFontId =
            QFontDatabase::addApplicationFont(":/MaterialSymbolsOutlined.ttf");
            QFontDatabase::addApplicationFont(":/MaterialSymbolsRounded.ttf");
            QFontDatabase::addApplicationFont(":/MaterialSymbolsSharp.ttf");

        if (materialSymbolsFontId == -1) {
            qWarning() << "Failed to load Material Symbols font";
        } else {
            qDebug() << "Material Symbols font loaded";
        }
    }

    QQmlEngine *engine = qmlEngine(this);
    if (engine)
    {
      engine->rootContext()->setContextProperty("gitex_demo_overlay", this);
    }
    else
    {
      qWarning("qmlEngine(this) is null context not set");
    }
  }

  QString QmlRosGitexDemoOverlayDisplay::getPathToQml()
  {
    return "package://nimblbot_rviz_overlay/media/overlay_gitex_demo.qml";
  }

  void QmlRosGitexDemoOverlayDisplay::onModuleLockTopic(const std_msgs::msg::Int8MultiArray::SharedPtr msg)
  {
    QVariantList lock_indices;

    for (const auto &value : msg->data)
    {
      lock_indices << static_cast<int>(value); // conversion en int pour QML
    }

    // Émettre vers QML (exemple)
    emit moduleLockTopicChanged(lock_indices);
  }

} // namespace gitex_demo_rviz_overlay

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(gitex_demo_rviz_overlay::QmlRosGitexDemoOverlayDisplay, rviz_common::Display)
