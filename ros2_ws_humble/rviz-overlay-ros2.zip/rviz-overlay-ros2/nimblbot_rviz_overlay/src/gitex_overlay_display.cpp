/*
 * Copyright (C) 2018  Stefan Fabian
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "gitex_rviz_overlay/gitex_overlay_display.hpp"

namespace gitex_rviz_overlay
{
  QmlRosGitexOverlayDisplay::QmlRosGitexOverlayDisplay()
      : hector_rviz_overlay::QmlOverlayDisplay()
  {
    QQmlEngine *engine = qmlEngine(this);
    if (engine)
    {
      engine->rootContext()->setContextProperty("gitex_overlay", this);
    }
    else
    {
      qWarning("qmlEngine(this) is null context not set");
    }
  }

  QString QmlRosGitexOverlayDisplay::getPathToQml()
  {
    return "package://nimblbot_rviz_overlay/media/overlay_gitex.qml";
  }

  void QmlRosGitexOverlayDisplay::onModuleLockTopic(const std_msgs::msg::Int8MultiArray::SharedPtr msg)
  {
    QVariantList lock_indices;

    for (const auto &value : msg->data)
    {
      lock_indices << static_cast<int>(value); // conversion en int pour QML
    }

    // Émettre vers QML (exemple)
    emit moduleLockTopicChanged(lock_indices);
  }

} // namespace gitex_rviz_overlay

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(gitex_rviz_overlay::QmlRosGitexOverlayDisplay, rviz_common::Display)
