/*
 * Copyright (C) 2018  Stefan Fabian
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "nimblbot_rviz_overlay/nimblbot_overlay_display.hpp"

namespace nimblbot_rviz_overlay
{
  QmlRosNimblbotOverlayDisplay::QmlRosNimblbotOverlayDisplay()
      : hector_rviz_overlay::QmlOverlayDisplay()
  {
    QQmlEngine *engine = qmlEngine(this);
    if (engine)
    {
      engine->rootContext()->setContextProperty("nimblbot_overlay", this);
    }
    else
    {
      qWarning("qmlEngine(this) is null context not set");
    }
  }

  QString QmlRosNimblbotOverlayDisplay::getPathToQml()
  {
    return "package://nimblbot_rviz_overlay/media/overlay.qml";
  }

  void QmlRosNimblbotOverlayDisplay::onModuleLockTopic(const std_msgs::msg::Int8MultiArray::SharedPtr msg)
  {
    QVariantList lock_indices;

    for (const auto &value : msg->data)
    {
      lock_indices << static_cast<int>(value); // conversion en int pour QML
    }

    // Émettre vers QML (exemple)
    emit moduleLockTopicChanged(lock_indices);
  }

  // void QmlRosNimblbotOverlayDisplay::onInitialize()
  // {

  //   engine()->rootContext()->setContextProperty("myBridge", bridge);
  // }
} // namespace nimblbot_rviz_overlay

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(nimblbot_rviz_overlay::QmlRosNimblbotOverlayDisplay, rviz_common::Display)
